import { Component, OnInit, ViewChild } from '@angular/core';
import swal from 'sweetalert2';
import xml2js from 'xml2js';
import { CSVRecord } from '../interface/csvrecord';

@Component({
  selector: 'app-csv-to-table',
  templateUrl: './csv-to-table.component.html',
  styleUrls: ['./csv-to-table.component.scss']
})

export class CsvToTableComponent implements OnInit {

 public csvRecords: any[] = [];
 uploadedFileName = '';
 filterCount = '';
  @ViewChild('fileImportInput', { static: false }) fileImportInput: any;
  headerData;
  xmlRecords;
  showCSVRecords: boolean = false;
  showXMLRecords: boolean = false;
  headerXMLData: any[];
  noDataMsg: boolean = false;

  constructor() { }

  ngOnInit() {
  }

  /** PROCESS FILE SELECTION AND RENDER THE DATA FROM CSV/XML FILE IN TABLE*/
  fileChangeListener($event: any): void {
    let files = $event.srcElement.files;
    this.uploadedFileName = files[0].name;
    if (this.isCSVFile(files[0])) {
       
      this.showXMLRecords = false;
      this.showCSVRecords = true;
      let input = $event.target;
      let reader = new FileReader();
      reader.readAsText(input.files[0]);
      reader.onload = () => {
        let csvData = reader.result;
        let csvRecordsArray = (<string>csvData).split(/\r\n|\n/);
        this.headerData = this.getHeaderArray(csvRecordsArray);
        console.log('headersRow', this.headerData);
        const csvDataList = this.getDataRecordsFromCSVFile(csvRecordsArray, this.headerData.length);
        console.log(csvDataList);
        this.xmlRecords = [];
       this.csvRecords = this.getFailedRecords(csvDataList);
       console.log(this.csvRecords);
       
      };
      reader.onerror = function () {
        swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Unable to read ' + input.files[0],
        })
      };
    }else if (this.isXmlFile(files[0])) {
       
      this.showCSVRecords = false;
      this.showXMLRecords = true;
      const input = $event.target;
      const reader = new FileReader();
      reader.readAsText(input.files[0]);
      reader.onload = () => {
        const xmlData = reader.result;
        const tableData = new Promise(resolve => {
          var k: string | number,
            arr = [],
            parser = new xml2js.Parser(
              {
                trim: true,
                explicitArray: true
              });
          parser.parseString(xmlData, function (err, result) {
            var obj = result.records;

            for (k in obj.record) {
              var item = obj.record[k];
              arr.push({
                reference: item.$.reference,
                accountNumber: item.accountNumber[0],
                description: item.description[0],
                startBalance: item.startBalance[0],
                Mutation: item.mutation[0],
                endBalance: item.endBalance[0]
              });
            }
            resolve(arr);
          });
        });
        return tableData.then(data => {
          const changeHeaderFormat = Object.keys(data[0]).map(item => {
          const result = item.replace( /([A-Z])/g, " $1" );
          const finalResult = result.charAt(0).toUpperCase() + result.slice(1);
          return finalResult
          })
          this.headerXMLData = changeHeaderFormat;
          console.log('------', this.headerXMLData);
          const xmlList = data;
          this.csvRecords = [];
          this.xmlRecords = this.getFailedRecords(xmlList);
          
        })
      };
    } else {
      swal.fire("Please import valid .csv or .xml file.");
      this.clearFile();
    }
  }

  /** GET UNIQUE REFERENCE */
  getUniqueReference(data) {
    const uniqueRefernce = Array.from(new Set(data.map(a => a.reference))).map(ref => {
      return data
      .find(a => a.reference === ref)      
    });
    return uniqueRefernce;
  }

  /**FILTER FAILED RECORDS */
  getFailedRecords(data){
    if(data.length>0){
      this.noDataMsg = false;
     const uniqueRefernce = this.getUniqueReference(data);
     console.log('', JSON.stringify(data));
      const failedReports = uniqueRefernce.filter(item => {
        return item.endBalance.startsWith('-');
      });
      return failedReports;
    } else {
      this.noDataMsg = true;
    }
   
  }

  trackByRefernce(index: number, ref: any): string {
    return ref.reference;
}

  /** GET DATA FROM CSV FILE */
  getDataRecordsFromCSVFile(csvRecordsArray: any, headerLength: any) {
    let dataArr = [];
    for (let i = 1; i < csvRecordsArray.length; i++) {
      let data = (<string>csvRecordsArray[i]).split(',');
      if (data.length == headerLength) {
        let csvRecord: CSVRecord = new CSVRecord();
        csvRecord.reference = data[0].replace(/['"]+/g, '').trim();
        csvRecord.accountNumber = data[1].replace(/['"]+/g, '').trim();
        csvRecord.description = data[2].trim();
        csvRecord.startBalance = data[3].replace(/['"]+/g, '').trim();
        csvRecord.Mutation = data[4].replace(/['"]+/g, '').trim();
        csvRecord.endBalance = data[5].replace(/['"]+/g, '').trim();
        dataArr.push(csvRecord);
      }
    }
    return dataArr;
  }
  /** CHECK IF FILE IS A VALID CSV FILE */
  isCSVFile(file: any) {
    return file.name.endsWith(".csv");
  }
  isXmlFile(file: any) {
    return file.name.endsWith(".xml");
  }
  /** GET CSV FILE HEADER COLUMNS */
  getHeaderArray(csvRecordsArr: any) {
    let headers = (<string>csvRecordsArr[0]).split(',');
    let headerArray = [];
    for (let j = 0; j < headers.length; j++) {
      headerArray.push(headers[j]);
    }
    return headerArray;
  }
  /** RESET OR CLEAR THE CSV FILE WHICH ALREADY SELECTED  */
  clearFile() {
    this.fileImportInput.nativeElement.value = "";
    this.uploadedFileName = '';
    this.csvRecords = [];
    this.xmlRecords = [];
  }

}
