export class CSVRecord {
    public reference: any;
    public accountNumber: any;
    public description: any;
    public startBalance: any;
    public Mutation: any;
    public endBalance: any;
  }
