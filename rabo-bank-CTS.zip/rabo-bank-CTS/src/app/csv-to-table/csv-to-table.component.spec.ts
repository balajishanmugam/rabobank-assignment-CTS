import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CsvToTableComponent } from './csv-to-table.component';
import { FormsModule } from '@angular/forms';


describe('CsvToTableComponent', () => {
  let component: CsvToTableComponent;
  let fixture: ComponentFixture<CsvToTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule ],
      declarations: [ CsvToTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CsvToTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('File selection label should be Select CSV or XML File', ()=> {
    fixture = TestBed.createComponent(CsvToTableComponent);
    component = fixture.componentInstance;
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('.upload-file-label').textContent).toContain('Select CSV or XML File');
  });

  it('File extension ends with CSV', () => {
    fixture = TestBed.createComponent(CsvToTableComponent);
    component = fixture.componentInstance;
    let fileName = {name: 'records.csv'};
    expect(component.isCSVFile(fileName)).toBeTruthy();
  });
  it('File extension ends with XML', () => {
    fixture = TestBed.createComponent(CsvToTableComponent);
    component = fixture.componentInstance;
    let fileName = {name: 'records.xml'};
    expect(component.isXmlFile(fileName)).toBeTruthy();
  });

  it('all transaction references should be unique ', () => {
    fixture = TestBed.createComponent(CsvToTableComponent);
    component = fixture.componentInstance;
    const dataArr = [{"reference":"177666","accountNumber":"NL93ABNA0585619023","description":"Flowers for Rik Theu�","startBalance":"44.85","Mutation":"-22.24","endBalance":"22.61"},{"reference":"112806","accountNumber":"NL69ABNA0433647324","description":"Subscription for Jan Theu�","startBalance":"45.59","Mutation":"+48.18","endBalance":"93.77"},{"reference":"158338","accountNumber":"NL91RABO0315273637","description":"Tickets for Vincent King","startBalance":"12.76","Mutation":"-39.5","endBalance":"-26.74"},{"reference":"193499","accountNumber":"NL93ABNA0585619023","description":"Candy for Dani�l Dekker","startBalance":"88.44","Mutation":"-13.28","endBalance":"75.16"},{"reference":"112806","accountNumber":"NL90ABNA0585647886","description":"Clothes from Peter de Vries","startBalance":"32.76","Mutation":"+49.03","endBalance":"81.79"},{"reference":"112806","accountNumber":"NL91RABO0315273637","description":"Tickets for Erik Dekker","startBalance":"41.63","Mutation":"+12.41","endBalance":"54.04"},{"reference":"108230","accountNumber":"NL32RABO0195610843","description":"Flowers for Willem Bakker","startBalance":"43.63","Mutation":"-12.18","endBalance":"31.45"},{"reference":"196213","accountNumber":"NL32RABO0195610843","description":"Subscription from Rik de Vries","startBalance":"30.36","Mutation":"-35.1","endBalance":"-4.74"},{"reference":"109762","accountNumber":"NL93ABNA0585619023","description":"Flowers from Rik de Vries","startBalance":"47.45","Mutation":"+17.82","endBalance":"65.27"},{"reference":"163590","accountNumber":"NL27SNSB0917829871","description":"Tickets from Rik Bakker","startBalance":"105.11","Mutation":"+29.87","endBalance":"134.98"}]
    expect(component.getUniqueReference(dataArr).length).toBe(8);
  });

  it('failed records in CSV File should be 2 ', () => {
    fixture = TestBed.createComponent(CsvToTableComponent);
    component = fixture.componentInstance;
    const dataArr = [{"reference":"177666","accountNumber":"NL93ABNA0585619023","description":"Flowers for Rik Theu�","startBalance":"44.85","Mutation":"-22.24","endBalance":"22.61"},{"reference":"112806","accountNumber":"NL69ABNA0433647324","description":"Subscription for Jan Theu�","startBalance":"45.59","Mutation":"+48.18","endBalance":"93.77"},{"reference":"158338","accountNumber":"NL91RABO0315273637","description":"Tickets for Vincent King","startBalance":"12.76","Mutation":"-39.5","endBalance":"-26.74"},{"reference":"193499","accountNumber":"NL93ABNA0585619023","description":"Candy for Dani�l Dekker","startBalance":"88.44","Mutation":"-13.28","endBalance":"75.16"},{"reference":"112806","accountNumber":"NL90ABNA0585647886","description":"Clothes from Peter de Vries","startBalance":"32.76","Mutation":"+49.03","endBalance":"81.79"},{"reference":"112806","accountNumber":"NL91RABO0315273637","description":"Tickets for Erik Dekker","startBalance":"41.63","Mutation":"+12.41","endBalance":"54.04"},{"reference":"108230","accountNumber":"NL32RABO0195610843","description":"Flowers for Willem Bakker","startBalance":"43.63","Mutation":"-12.18","endBalance":"31.45"},{"reference":"196213","accountNumber":"NL32RABO0195610843","description":"Subscription from Rik de Vries","startBalance":"30.36","Mutation":"-35.1","endBalance":"-4.74"},{"reference":"109762","accountNumber":"NL93ABNA0585619023","description":"Flowers from Rik de Vries","startBalance":"47.45","Mutation":"+17.82","endBalance":"65.27"},{"reference":"163590","accountNumber":"NL27SNSB0917829871","description":"Tickets from Rik Bakker","startBalance":"105.11","Mutation":"+29.87","endBalance":"134.98"}]
    expect(component.getFailedRecords(dataArr).length).toBe(2);
  });
  it('failed records in XML file should be 1 ', () => {
    fixture = TestBed.createComponent(CsvToTableComponent);
    component = fixture.componentInstance;
    const dataArr =  [{"reference":"187997","accountNumber":"NL91RABO0315273637","description":"Clothes for Rik King","startBalance":"57.6","Mutation":"-32.98","endBalance":"24.62"},{"reference":"154270","accountNumber":"NL56RABO0149876948","description":"Candy for Peter de Vries","startBalance":"5429","Mutation":"-939","endBalance":"6368"},{"reference":"162197","accountNumber":"NL90ABNA0585647886","description":"Tickets for Daniël de Vries","startBalance":"95.03","Mutation":"+48.33","endBalance":"143.36"},{"reference":"129635","accountNumber":"NL27SNSB0917829871","description":"Clothes for Vincent King","startBalance":"14.48","Mutation":"+16.39","endBalance":"30.87"},{"reference":"148503","accountNumber":"NL93ABNA0585619023","description":"Subscription from Willem Dekker","startBalance":"30.54","Mutation":"-13.18","endBalance":"17.36"},{"reference":"163023","accountNumber":"NL43AEGO0773393871","description":"Tickets for Daniël de Vries","startBalance":"37.79","Mutation":"-40.84","endBalance":"-3.05"},{"reference":"162410","accountNumber":"NL69ABNA0433647324","description":"Tickets from Jan Bakker","startBalance":"10.1","Mutation":"-0.3","endBalance":"9.8"},{"reference":"112747","accountNumber":"NL56RABO0149876948","description":"Candy from Jan Dekker","startBalance":"51.62","Mutation":"-42.36","endBalance":"9.26"},{"reference":"140269","accountNumber":"NL43AEGO0773393871","description":"Tickets for Vincent Dekker","startBalance":"3980","Mutation":"+1000","endBalance":"4981"},{"reference":"115137","accountNumber":"NL43AEGO0773393871","description":"Flowers for Jan Theuß","startBalance":"28.19","Mutation":"+3.22","endBalance":"31.41"}];
    expect(component.getFailedRecords(dataArr).length).toBe(1);
  });

});
